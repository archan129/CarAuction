Admin Login Info
Username: Admin
Password: Admin129

Customer Rep
Username: rep1
Password: rep129